# Exercise 4 - Chinese Medicine Procedure

## [E7P4Q1] Which recognized terminology sets are adopted for eHealth CMPX records in the eHRSS?

A. SNOMED CT and ICD-10

B. ICD-9 and HKCTT

C. LOINC and HKCTT

D. HKCTT and GB97

Answer: &lt;PUT YOUR ANSWER HERE&gt;

## [E7P4Q2] What is the fixed value for the Procedure.status element in an eHealth CMPX record?

(A) in-progress

(B) completed

(C) not-done

(D) on-hold

Answer: &lt;PUT YOUR ANSWER HERE&gt;
