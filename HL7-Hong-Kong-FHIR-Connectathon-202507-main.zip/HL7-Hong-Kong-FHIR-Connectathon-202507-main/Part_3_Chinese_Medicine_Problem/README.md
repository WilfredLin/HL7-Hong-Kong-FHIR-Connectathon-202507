# Exercise 3 - Chinese Medicine Problem

## [E7P3Q1] Which element in the Condition resource is mandatory for an eHealth CMPROB record to identify the patient?

(A) patient.reference

(B) subject.reference

(C) author.reference

(D) user.reference

Answer: &lt;PUT YOUR ANSWER HERE&gt;

## [E7P3Q2] What is the role of the CarePlan resource in an eHealth CMPROB record?

(A) It contains the patient’s demographic data

(B) It describes the Chinese Medicine treatment approach related to the problem

(C) It specifies the clinical status of the condition

(D) It identifies the healthcare institution

Answer: &lt;PUT YOUR ANSWER HERE&gt;
