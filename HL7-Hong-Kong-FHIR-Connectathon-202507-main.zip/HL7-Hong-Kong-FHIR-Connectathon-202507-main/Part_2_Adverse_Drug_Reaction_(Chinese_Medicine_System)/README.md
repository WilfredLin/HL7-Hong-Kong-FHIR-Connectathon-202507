# Exercise 2 - Adverse Drug Reaction (Chinese Medicine System)

## [E7P2Q1] Which element in the AllergyIntolerance resource is the most reliable indicator for distinguishing between an eHealth CMADR and an eHealth CMAL1 record?

(A) The AllergyIntolerance.type element

(B) The AllergyIntolerance.note element

(C) The AllergyIntolerance.clinicalStatus element

(D) The AllergyIntolerance.code.coding.system element

Answer: &lt;PUT YOUR ANSWER HERE&gt;
